using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MouseInputHandler : MonoBehaviour
{
    private float timer = 0f;
    private bool isMousePressed = false;

    void Update()
    {
        // Check if the left mouse button is pressed
        if (Input.GetMouseButtonDown(0))
        {
            isMousePressed = true;
            timer = 0f;
        }

        // Check if the left mouse button is released
        if (Input.GetMouseButtonUp(0))
        {
            isMousePressed = false;
            timer = 0f;
        }

        // Check if the mouse's x-axis location is less than 0
        if (Input.mousePosition.x < 0)
        {
            timer += Time.deltaTime;

            // Check if the left mouse button is pressed for three seconds
            if (isMousePressed && timer >= 3f)
            {
                CloseProgram();
            }
        }

        // Check if the Escape key is pressed
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            CloseProgram();
        }
    }

    private void CloseProgram()
    {
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}