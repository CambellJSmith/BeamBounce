using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTrack : MonoBehaviour
{
    // Reference to the player's transform component
    private Transform playerTransform;

    // Variable to store the target position of the player
    private Vector3 targetPosition;

    // Variable to check if the left mouse button is pressed
    private bool isMousePressed = false;

    private void Start()
    {
        // Get the player's transform component
        playerTransform = transform;
    }

    private void Update()
    {
        // Check for left mouse button press
        if (Input.GetMouseButtonDown(0))
        {
            // Store the current mouse position as the target position
            targetPosition = GetMouseWorldPosition();

            // Set the flag to indicate that the left mouse button is pressed
            isMousePressed = true;
        }

        // Check for left mouse button release
        if (Input.GetMouseButtonUp(0))
        {
            // Reset the flag to indicate that the left mouse button is released
            isMousePressed = false;
        }

        // Move the player towards the target position only if the mouse button is pressed
        if (isMousePressed)
        {
            // Set the target position with z = 0
            targetPosition.z = 0f;

            // Move the player towards the target position using translation
            playerTransform.position = targetPosition;
        }
    }

    private Vector3 GetMouseWorldPosition()
    {
        // Get the mouse position in screen coordinates
        Vector3 mouseScreenPosition = Input.mousePosition;

        // Set the z-coordinate to the desired value (0 in this case)
        mouseScreenPosition.z = 0f;

        // Convert the mouse position from screen coordinates to world coordinates
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);

        // Return the mouse position in world coordinates
        return mouseWorldPosition;
    }
}
