using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ReloadSceneOnClick : MonoBehaviour
{
    private void Update()
    {
        // Check if Player.PlayerLive is 0
        if (Player.PlayerLive == 0)
        {
            // Set the object's position to (7777, 7777, 0)
            transform.position = new Vector3(7777f, 7777f, 0f);
        }
        // Check if Player.PlayerLive is 1
        else if (Player.PlayerLive == 1)
        {
            // Set the object's position to (5, 0, 0)
            transform.position = new Vector3(0f, 2f, 0f);
            
            // Check for left mouse button click with x position greater than 0
            if (Input.GetMouseButtonDown(0) && Input.mousePosition.x > 0)
            {
                // Reload the current scene
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
                
                // Set Player.PlayerLive to 0
                Player.PlayerLive = 0;
                
                // Set GameManager.Score to 0
                GameManager.Score = 0;
            }
        }
    }
}
