using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject prefabToSpawn; // Reference to the prefab to be spawned
    public float initialSpawnDelay = 1f; // Initial delay before the first spawn
    public float spawnRateDecrease = 0.1f; // Amount of time the spawn rate decreases per second
    public float minSpawnRate = 0.25f; // Minimum time between spawns

    private float spawnRate; // Current time between spawns
    private float timer; // Timer to track the next spawn

    private void Start()
    {
        spawnRate = initialSpawnDelay; // Set the initial spawn rate
        timer = spawnRate; // Start the timer with the initial spawn rate
    }

    private void Update()
    {
        // Decrease the spawn rate over time
        spawnRate -= spawnRateDecrease * Time.deltaTime;

        // Ensure the spawn rate doesn't go below the minimum
        spawnRate = Mathf.Max(spawnRate, minSpawnRate);

        // Update the timer
        timer -= Time.deltaTime;

        // Check if it's time to spawn a new prefab
        if (timer <= 0f)
        {
            SpawnPrefab();
            timer = spawnRate; // Reset the timer for the next spawn
        }
    }

    private void SpawnPrefab()
    {
        // Instantiate the prefab at the spawner's position and rotation
        Instantiate(prefabToSpawn, transform.position, transform.rotation);
    }
}
