using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserShimmer : MonoBehaviour
{
    // The two scale values to swap between
    public Vector3 firstScale = new Vector3(0.1f, 50f, 1f);
    public Vector3 secondScale = new Vector3(0.2f, 50f, 1f);

    // Time interval for swapping between scales
    public float swapInterval = 0.05f;

    private Vector3 originalScale;
    private bool isSwapping = false;

    private void Start()
    {
        // Store the original scale of the object
        originalScale = transform.localScale;

        // Start the shimmering process
        StartShimmer();
    }

    private void StartShimmer()
    {
        // Set the initial scale to the first scale value
        transform.localScale = firstScale;

        // Start the shimmering coroutine
        StartCoroutine(ShimmerCoroutine());
    }

    private System.Collections.IEnumerator ShimmerCoroutine()
    {
        // Infinite loop for continuously swapping scales
        while (true)
        {
            // Wait for the specified interval
            yield return new WaitForSeconds(swapInterval);

            // Check if already swapping scales
            if (isSwapping)
                continue;

            // Start swapping scales
            isSwapping = true;

            // Check which scale to apply based on the current scale
            if (transform.localScale == firstScale)
                transform.localScale = secondScale;
            else
                transform.localScale = firstScale;

            // End swapping scales
            isSwapping = false;
        }
    }
}
