using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreMotion : MonoBehaviour
{
    public Transform objectToMove;
    public float duration = 1f;

    private bool shouldMove = false;
    private Vector3 initialPosition;
    private Vector3 targetPosition;
    private Vector3 initialScale;
    private Vector3 targetScale;
    private float elapsedTime = 0f;

    private void Start()
    {
        transform.position = new Vector3(Camera.main.transform.position.x, Camera.main.ScreenToWorldPoint(Vector3.zero).y + 1, 0f);
        initialPosition = objectToMove.position;
        targetPosition = new Vector3(0f, 0f, 0f);
        initialScale = objectToMove.localScale;
        targetScale = new Vector3(2f, 2f, 0f);
    }

    private void Update()
    {
        if (Player.PlayerLive == 1)
        {
            shouldMove = true;
        }
        else
        {
            shouldMove = false;
        }

        if (shouldMove)
        {
            if (elapsedTime < duration)
            {
                float t = elapsedTime / duration;
                objectToMove.position = Vector3.Lerp(initialPosition, targetPosition, t);
                objectToMove.localScale = Vector3.Lerp(initialScale, targetScale, t);
                elapsedTime += Time.deltaTime;
            }
            else
            {
                objectToMove.position = targetPosition;
                objectToMove.localScale = targetScale;
            }
        }
    }
}
