using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TMPScore : MonoBehaviour
{
    public TextMeshProUGUI scoreText;

    private void Update()
    {
        // Assuming GameManager is a static class with a static property called Score
        float score = GameManager.Score;
        scoreText.text = score.ToString();
    }
}