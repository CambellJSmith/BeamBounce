using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerArm : MonoBehaviour
{
    // The minimum and maximum rotation angles on the z-axis.
    public float minRotation = 0f;
    public float maxRotation = 360f;

    // Reference to the transform component.
    private Transform armTransform;

    private void Start()
    {
        // Get the transform component of the current game object.
        armTransform = GetComponent<Transform>();
    }

    private void Update()
    {
        // Generate a random rotation angle within the specified range.
        float randomRotation = Random.Range(minRotation, maxRotation);

        // Create a new rotation based on the existing rotation and the random rotation angle.
        Quaternion newRotation = Quaternion.Euler(armTransform.rotation.eulerAngles.x, armTransform.rotation.eulerAngles.y, randomRotation);

        // Apply the new rotation to the arm.
        armTransform.rotation = newRotation;
    }
}
