using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static float PlayerLive = 0; // Is the player still alive?
    public Transform playerTrack; // Reference to the object to track
    private Rigidbody2D rb; // Reference to the Rigidbody2D component

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>(); // Get the Rigidbody2D component
    }

    private void Update()
    {
        // Move towards the playerTrack object quickly
        transform.position = Vector2.MoveTowards(transform.position, playerTrack.position, Time.deltaTime * 20f);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Finish"))
        {
            PlayerLive = 1; // Set the player live variable to dead.
            Destroy(gameObject); // Destroy the object if it collides with an object tagged "Finish"
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Finish"))
        {
            PlayerLive = 1; // Set the player live variable to dead.
            Destroy(gameObject); // Destroy the object if it collides with an object tagged "Finish"
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Finish"))
        {
            PlayerLive = 1; // Set the player live variable to dead.
            Destroy(gameObject); // Destroy the object if it collides with an object tagged "Finish"
        }
    }
}
