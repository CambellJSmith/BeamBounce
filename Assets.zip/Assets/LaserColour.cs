using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserColour : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;  // Reference to the object's SpriteRenderer component

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();  // Get the SpriteRenderer component attached to the object

        // Set the initial color to light grey
        SetColor(Color.gray);

        // Call the ChangeColor method after exactly one second
        Invoke("ChangeColor", 1f);
    }

    private void SetColor(Color color)
    {
        spriteRenderer.color = color;  // Set the color of the SpriteRenderer to the specified color
    }

    private void ChangeColor()
    {
        SetColor(Color.red);  // Change the color to red
        gameObject.tag = "Finish";  // Change the object's tag to "Finish"
    }
}