using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserScore : MonoBehaviour
{
    public float rotationSpeed = 10f;  // Speed of rotation in degrees per second

    private void Start()
    {
        //Set the laser to a random rotation upon spawn.
        transform.rotation = Quaternion.Euler(0f, 0f, Random.Range(0f, 360f));

        // Invoke the DestroyObject method after two seconds
        Invoke("DestroyObject", 2f);
    }

    // Update is called once per frame
    void Update()
    {
        // Rotate the object around its own Z-axis
        transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);

        if(Player.PlayerLive == 1) //If the player has collided with a laser
        {
            Destroy(gameObject); //destoy all lasers
        }
    }

    private void DestroyObject()
    {
        // Increase the score by 1
        GameManager.Score += 1f;

        // Destroy the game object this script is attached to
        Destroy(gameObject);
    }
}
